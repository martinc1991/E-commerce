const server = require('express').Router();
const { Categories } = require('../db.js');

server.post('/category/', (req, res, next) => {
    Categories.create({
        name: req.body.name,
        description: req.body.description
    })
    .then((newCategory)=>{
        return res.status(201)
        .json({
            message:`La categoria ${newCategory.name} ha sido creada exitosamente`,
            data:newCategory  
        })
    })
    .catch(err =>{
        return res.status(401)
        .json({
            message: err
        })
    }); 
		
});

server.delete('/category/:id', (req, res, next) => {
    return Categories.findOne({
         where:{
             id: req.params.id
         }
     })
         .then(category => {                      
             var categoryName = category.name;
             category.destroy()
             return res.status(202)
             .json({
                 message:`Se elimino la categoria ${categoryName}`,
                 data:category 
             })             
         })
         
         .catch(err =>{
            return res.status(401)
            .json({
                message: err
            })
         });
 });

server.put('/category/:id', (req, res, next) => {
    return Categories.findOne({
         where:{
             id: req.params.id
         }
     })
         .then(category => {             
            var categoryName = category.name;
            category.name = req.body.name;
            category.description = req.body.description;
            category.save()
            return res.status(204)
            .json({
                message:`Se ha modificado la categoria ${categoryName} correctamente`,
                data:category
            })
             
         })
         .catch(err =>{
            return res.status(401)
            .json({
                message: err
            })
         });
 });

module.exports = server;