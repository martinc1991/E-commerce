const server = require('express').Router();
const { Product, Categories } = require('../db.js');

server.get('/', (req, res) => {
	Product.findAll()
		.then(products => {
			res.json({
				message: 'Success',
				data: products
			});
		})
		.catch(err =>{
			return res.status(404)
			.json({
				message: err
			})
		});
});
server.post('/',(req, res)=>{
	let cat;
	
	Product.create({
		name: req.body.name,
		price: req.body.price,
		stock: req.body.stock
	})
	.then((product)=>{
		Categories.findOne({
			where:{
				id:req.body.cat
			}
		}).then((category)=>{
			product.addCategory(category)
		})						
		return res.status(201)
        .json({
            message:`El producto ${newProduct.name} ha sido creado exitosamente`,
            data:newProduct  
        })
	})
	
    .catch(err =>{
        return res.status(401)
        .json({
            message: err
        })
	})

	
	
	
	

})
server.post('/:idproduct/category/:idcategory',(req, res)=>{
	Product.findOne({
		where:{
			id:req.params.idproduct
		},
		include:[{
			model: Categories
		}]
	})

})


module.exports = server;
